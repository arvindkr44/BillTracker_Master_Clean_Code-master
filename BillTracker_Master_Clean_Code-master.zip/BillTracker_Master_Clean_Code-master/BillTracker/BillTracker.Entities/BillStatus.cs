﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillTracker.Entities
{
    public enum BillStatus
    {
        Paid,
        Unpaid
    }
}
